//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDC_TUTORIAL                    101
#define IDI_SMALL                       102
#define IDI_TUTORIAL                    103
#define IDR_MENU1                       105
#define IDD_DIALOG1                     112
#define IDD_ABOUTBOX                    112
#define IDB_BITMAP1                     116
#define IDM_ABOUT                       40001
#define ID_FILE_EXIT                    40004
#define ID_HELP_ABOUT                   40005
#define IDM_EXIT                        40006
#define ID_FILE_NEWGAME                 40007
#define ID_BACKGROUND_COLOR             40008
#define ID_BACKGROUND_BITMAP            40009
#define ID_BACKGROUND_TILE              40010
#define ID_BACKGROUND_STRECH            40011
#define ID_RESET                        40012
#define IDM_RESET                       40013
#define ID_Menu                         40025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40027
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
